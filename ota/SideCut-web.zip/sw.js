const CACHE_NAME = 'sidecut-shell-v85.3.11';
const SHELL_FILES = ['./index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      // no-store for the same reason as the fetch handler below: the offline
      // copy of index.html must not come from GitHub Pages' 10 minute HTTP cache.
      .then((cache) => Promise.all(
        SHELL_FILES.map((f) => cache.add(new Request(f, { cache: 'no-store' })).catch(() => {}))
      ))
      .then(() => self.skipWaiting()) // Wait for cache before activating
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
      .then(() => self.clients.matchAll())
      .then((clients) => clients.forEach((c) => c.postMessage({ type: 'SW_UPDATED', version: CACHE_NAME })))
  );
});

// Auto-update cache: index.html (and other same-origin shell files) go network-first,
// so a visit while online always checks for a newer version instead of quietly serving
// a stale cached copy. Falls back to whatever's cached the moment the network fails,
// so it still works offline. Everything cross-origin (fonts, JSZip CDN) just goes to network.
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);
  
  // Skip non-http(s) requests (blob:, data:, about:, etc.) and cross-origin requests
  if (!url.protocol.startsWith('http') || url.origin !== self.location.origin) return;

  // A reload must always be able to pick up a newer build. GitHub Pages serves
  // index.html with a 10 minute max-age, and a plain fetch() happily answers
  // from that HTTP cache — which is why new versions looked like they never
  // arrived. Bypass the HTTP cache for page loads so the newest HTML wins.
  const isDocument = event.request.mode === 'navigate' || event.request.destination === 'document';
  const netRequest = isDocument
    ? new Request(event.request.url, { cache: 'no-store', credentials: 'same-origin', mode: 'same-origin' })
    : event.request;

  event.respondWith(
    fetch(netRequest)
      .then((networkResponse) => {
        // Only cache successful responses
        if (networkResponse.ok) {
          const copy = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
        }
        return networkResponse;
      })
      .catch(() => caches.match(event.request))
  );
});

// Lets a page ask the waiting/active worker to check for updates on demand
// (used by the in-app "Check for updates" flow) instead of only on page load.
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'CHECK_FOR_UPDATE') {
    self.registration.update().catch(() => {});
  }
});
